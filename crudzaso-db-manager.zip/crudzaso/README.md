# CrudZaso DB Manager

Plataforma web para administrar bases de datos MySQL, PostgreSQL y MongoDB de forma centralizada.

## Stack

- **Backend:** Java 21 · Spring Boot 3.2 · Spring Security · Spring Data JPA · Flyway
- **Frontend:** Thymeleaf · Bootstrap 5.3 · Chart.js
- **Base de datos:** PostgreSQL 16
- **Mail (dev):** MailHog
- **Contenedores:** Docker · Docker Compose

---

## Inicio rápido

```bash
# 1. Clonar o descomprimir el proyecto
cd crudzaso

# 2. Levantar todo con Docker Compose
docker compose up --build

# 3. Abrir en el navegador
# Aplicación:  http://localhost:8080
# Correos dev: http://localhost:8025
```

### Credenciales por defecto (admin)
| Campo    | Valor                  |
|----------|------------------------|
| Correo   | admin@crudzaso.com     |
| Password | Admin1234!             |

---

## Estructura del proyecto

```
src/main/java/com/crudzaso/dbmanager/
├── config/          SecurityConfig, AsyncConfig, SecurityHelper
├── controller/      AuthController, DashboardController, DatabaseController,
│                    ProfileController
│   └── admin/       AdminDashboardController, AdminUserController,
│                    AdminDatabaseController
├── dto/             UserRegistrationDTO, DatabaseCreateDTO, DatabaseEditDTO,
│                    ChangePasswordDTO, ProfileUpdateDTO
├── entity/          User, Database
│   └── enums/       Role, UserStatus, DbEngine, DbStatus
├── exception/       GlobalExceptionHandler + custom exceptions
├── repository/      UserRepository, DatabaseRepository
├── service/         UserService, DatabaseService, MailService,
│                    CredentialGeneratorService, PortAssignmentService,
│                    CustomUserDetailsService
└── util/            PasswordGenerator
```

---

## Reglas de negocio implementadas

- Máximo **3 bases de datos activas** por usuario
- Nombre único por usuario (combinación `nombre + propietario`)
- Motor **no modificable** una vez creada
- Puerto **único y no modificable**, asignado automáticamente (rango 15000–15999)
- Usuario y contraseña de conexión **generados automáticamente** y únicos en la plataforma
- Base archivada **irreversible** — no puede editarse ni reactivarse
- Usuario bloqueado **no puede iniciar sesión**
- **Correos automáticos** en: registro, recuperación de contraseña, cambio de contraseña, creación/archivado de DB, bloqueo/desbloqueo de usuario

---

## Variables de entorno

| Variable                   | Por defecto                            |
|----------------------------|----------------------------------------|
| `SPRING_DATASOURCE_URL`    | `jdbc:postgresql://db:5432/crudzaso`   |
| `SPRING_DATASOURCE_USERNAME` | `crudzaso`                           |
| `SPRING_DATASOURCE_PASSWORD` | `secret`                             |
| `MAIL_HOST`                | `localhost`                            |
| `MAIL_PORT`                | `1025`                                 |
| `APP_BASE_URL`             | `http://localhost:8080`                |

---

## Páginas disponibles

### Públicas
| Ruta                         | Descripción              |
|------------------------------|--------------------------|
| `/`                          | Landing page             |
| `/auth/login`                | Inicio de sesión         |
| `/auth/register`             | Registro                 |
| `/auth/forgot-password`      | Recuperar contraseña     |
| `/auth/reset-password?token` | Restablecer contraseña   |

### Usuario autenticado
| Ruta                        | Descripción                   |
|-----------------------------|-------------------------------|
| `/dashboard`                | Panel principal               |
| `/databases`                | Listado de bases de datos     |
| `/databases/new`            | Crear nueva                   |
| `/databases/{id}`           | Detalle y credenciales        |
| `/databases/{id}/edit`      | Editar descripción y estado   |
| `/profile`                  | Editar perfil                 |
| `/profile/change-password`  | Cambiar contraseña            |

### Administrador
| Ruta                        | Descripción                   |
|-----------------------------|-------------------------------|
| `/admin/dashboard`          | Panel administrativo          |
| `/admin/users`              | Gestión de usuarios           |
| `/admin/users/{id}`         | Detalle de usuario            |
| `/admin/databases`          | Gestión de bases de datos     |
| `/admin/databases/{id}`     | Detalle y cambio de estado    |
| `/admin/stats`              | Estadísticas con gráficas     |
