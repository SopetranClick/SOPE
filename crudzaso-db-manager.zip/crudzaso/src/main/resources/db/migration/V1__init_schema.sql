-- V1__init_schema.sql

CREATE TYPE user_role AS ENUM ('USER', 'ADMIN');
CREATE TYPE user_status AS ENUM ('ACTIVE', 'BLOCKED');
CREATE TYPE db_engine AS ENUM ('MYSQL', 'POSTGRESQL', 'MONGODB');
CREATE TYPE db_status AS ENUM ('CREATED', 'RUNNING', 'STOPPED', 'ARCHIVED');

CREATE TABLE users (
    id                      BIGSERIAL PRIMARY KEY,
    first_name              VARCHAR(100) NOT NULL,
    last_name               VARCHAR(100) NOT NULL,
    email                   VARCHAR(255) NOT NULL UNIQUE,
    password                VARCHAR(255) NOT NULL,
    role                    user_role    NOT NULL DEFAULT 'USER',
    status                  user_status  NOT NULL DEFAULT 'ACTIVE',
    password_reset_token    VARCHAR(255),
    password_reset_expiry   TIMESTAMP,
    created_at              TIMESTAMP    NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMP    NOT NULL DEFAULT NOW()
);

CREATE TABLE databases (
    id                  BIGSERIAL PRIMARY KEY,
    name                VARCHAR(100) NOT NULL,
    description         TEXT,
    engine              db_engine    NOT NULL,
    connection_user     VARCHAR(50)  NOT NULL UNIQUE,
    connection_password VARCHAR(255) NOT NULL UNIQUE,
    port                INTEGER      NOT NULL UNIQUE,
    status              db_status    NOT NULL DEFAULT 'CREATED',
    user_id             BIGINT       NOT NULL REFERENCES users(id),
    created_at          TIMESTAMP    NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMP    NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_db_name_user UNIQUE (name, user_id)
);

CREATE INDEX idx_databases_user_id ON databases(user_id);
CREATE INDEX idx_databases_status  ON databases(status);
CREATE INDEX idx_users_email       ON users(email);

-- Admin user por defecto (password: Admin1234!)
INSERT INTO users (first_name, last_name, email, password, role, status)
VALUES ('Admin', 'Sistema', 'admin@crudzaso.com',
        '$2a$12$XqFDRzXGHDvOvB.jHqCNHOb/b0c/C.I4j7VLUmwrx7mOvFv/K0cS6',
        'ADMIN', 'ACTIVE');
