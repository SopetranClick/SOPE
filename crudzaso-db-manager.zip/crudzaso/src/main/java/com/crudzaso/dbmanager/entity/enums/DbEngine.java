package com.crudzaso.dbmanager.entity.enums;
public enum DbEngine { MYSQL, POSTGRESQL, MONGODB }
