package com.crudzaso.dbmanager.config;

import com.crudzaso.dbmanager.repository.DatabaseRepository;
import com.crudzaso.dbmanager.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

@Component("sec")
@RequiredArgsConstructor
public class SecurityHelper {

    private final UserRepository userRepository;
    private final DatabaseRepository databaseRepository;

    public boolean isOwnerOrAdmin(Long dbId, Authentication auth) {
        if (auth == null) return false;
        boolean isAdmin = auth.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
        if (isAdmin) return true;

        return userRepository.findByEmail(auth.getName())
                .flatMap(user -> databaseRepository.findById(dbId)
                        .map(db -> db.getOwner().getId().equals(user.getId())))
                .orElse(false);
    }
}
