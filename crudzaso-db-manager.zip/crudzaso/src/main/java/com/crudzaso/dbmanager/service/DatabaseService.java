package com.crudzaso.dbmanager.service;

import com.crudzaso.dbmanager.dto.DatabaseCreateDTO;
import com.crudzaso.dbmanager.dto.DatabaseEditDTO;
import com.crudzaso.dbmanager.entity.Database;
import com.crudzaso.dbmanager.entity.User;
import com.crudzaso.dbmanager.entity.enums.DbEngine;
import com.crudzaso.dbmanager.entity.enums.DbStatus;
import com.crudzaso.dbmanager.exception.AccessDeniedException;
import com.crudzaso.dbmanager.exception.DatabaseLimitException;
import com.crudzaso.dbmanager.exception.DuplicateNameException;
import com.crudzaso.dbmanager.exception.ResourceNotFoundException;
import com.crudzaso.dbmanager.repository.DatabaseRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Transactional
public class DatabaseService {

    private final DatabaseRepository databaseRepository;
    private final UserService userService;
    private final CredentialGeneratorService credentialGenerator;
    private final PortAssignmentService portAssignment;
    private final MailService mailService;

    public Database create(DatabaseCreateDTO dto, Long userId) {
        User owner = userService.findById(userId);

        long active = databaseRepository.countActiveByOwner(userId);
        if (active >= 3)
            throw new DatabaseLimitException("Has alcanzado el límite de 3 bases de datos activas");

        if (databaseRepository.existsByNameAndOwner(dto.getName(), owner))
            throw new DuplicateNameException("Ya tienes una base de datos con ese nombre");

        Database db = Database.builder()
                .name(dto.getName())
                .description(dto.getDescription())
                .engine(dto.getEngine())
                .connectionUser(credentialGenerator.generateUniqueUser())
                .connectionPassword(credentialGenerator.generateSecurePassword())
                .port(portAssignment.assignAvailablePort())
                .status(DbStatus.CREATED)
                .owner(owner)
                .build();

        databaseRepository.save(db);
        mailService.sendDatabaseCreated(owner, db);
        return db;
    }

    @Transactional(readOnly = true)
    public Database findById(Long id) {
        return databaseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Base de datos no encontrada"));
    }

    @Transactional(readOnly = true)
    public Database findByIdForUser(Long id, Long userId, boolean isAdmin) {
        Database db = findById(id);
        if (!isAdmin && !db.getOwner().getId().equals(userId))
            throw new AccessDeniedException("No tienes acceso a esta base de datos");
        return db;
    }

    @Transactional(readOnly = true)
    public List<Database> findByOwner(Long userId) {
        User owner = userService.findById(userId);
        return databaseRepository.findByOwnerOrderByCreatedAtDesc(owner);
    }

    @Transactional(readOnly = true)
    public Page<Database> searchAdmin(String search, DbEngine engine, Pageable pageable) {
        return databaseRepository.searchAdmin(search, engine, pageable);
    }

    public Database update(Long id, DatabaseEditDTO dto, Long userId, boolean isAdmin) {
        Database db = findByIdForUser(id, userId, isAdmin);
        if (db.isArchived())
            throw new IllegalStateException("Una base de datos archivada no puede editarse");

        // No permitir reactivar desde ARCHIVED (si alguien manipula el form)
        if (dto.getStatus() == DbStatus.ARCHIVED) {
            archive(id, userId, isAdmin);
            return db;
        }

        db.setDescription(dto.getDescription());
        db.setStatus(dto.getStatus());
        return databaseRepository.save(db);
    }

    public void archive(Long id, Long userId, boolean isAdmin) {
        Database db = findByIdForUser(id, userId, isAdmin);
        if (db.isArchived())
            throw new IllegalStateException("La base de datos ya está archivada");

        db.setStatus(DbStatus.ARCHIVED);
        databaseRepository.save(db);
        mailService.sendDatabaseArchived(db.getOwner(), db);
    }

    // Admin: cambiar estado directamente
    public void changeStatus(Long id, DbStatus newStatus) {
        Database db = findById(id);
        if (db.isArchived() && newStatus != DbStatus.ARCHIVED)
            throw new IllegalStateException("Una base archivada no puede reactivarse");
        db.setStatus(newStatus);
        if (newStatus == DbStatus.ARCHIVED) mailService.sendDatabaseArchived(db.getOwner(), db);
        databaseRepository.save(db);
    }

    // Stats
    @Transactional(readOnly = true)
    public long countTotal()    { return databaseRepository.count(); }

    @Transactional(readOnly = true)
    public Map<String, Long> statsByEngine() {
        Map<String, Long> map = new LinkedHashMap<>();
        for (Object[] row : databaseRepository.countByEngine())
            map.put(((DbEngine) row[0]).name(), (Long) row[1]);
        return map;
    }

    @Transactional(readOnly = true)
    public Map<String, Long> statsByStatus() {
        Map<String, Long> map = new LinkedHashMap<>();
        for (Object[] row : databaseRepository.countByStatus())
            map.put(((DbStatus) row[0]).name(), (Long) row[1]);
        return map;
    }

    @Transactional(readOnly = true)
    public Map<String, Long> statsByOwner() {
        Map<String, Long> map = new LinkedHashMap<>();
        for (Object[] row : databaseRepository.countByOwner())
            map.put((String) row[0], (Long) row[1]);
        return map;
    }
}
