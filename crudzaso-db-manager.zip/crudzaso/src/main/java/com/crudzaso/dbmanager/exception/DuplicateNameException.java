package com.crudzaso.dbmanager.exception;
public class DuplicateNameException extends RuntimeException {
    public DuplicateNameException(String msg) { super(msg); }
}
