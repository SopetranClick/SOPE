package com.crudzaso.dbmanager.controller;

import com.crudzaso.dbmanager.dto.UserRegistrationDTO;
import com.crudzaso.dbmanager.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

    private final UserService userService;

    @GetMapping("/login")
    public String loginPage(@RequestParam(required = false) String error,
                            @RequestParam(required = false) String logout,
                            Model model) {
        if (error != null)  model.addAttribute("error", error);
        if (logout != null) model.addAttribute("success", "Sesión cerrada exitosamente");
        return "auth/login";
    }

    @GetMapping("/register")
    public String registerPage(Model model) {
        model.addAttribute("dto", new UserRegistrationDTO());
        return "auth/register";
    }

    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("dto") UserRegistrationDTO dto,
                           BindingResult result,
                           RedirectAttributes flash,
                           Model model) {
        if (result.hasErrors()) return "auth/register";

        try {
            userService.register(dto);
            flash.addFlashAttribute("success", "Cuenta creada. ¡Ya puedes iniciar sesión!");
            return "redirect:/auth/login";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            return "auth/register";
        }
    }

    @GetMapping("/forgot-password")
    public String forgotPage() { return "auth/forgot-password"; }

    @PostMapping("/forgot-password")
    public String forgotSubmit(@RequestParam String email, RedirectAttributes flash) {
        userService.initiatePasswordReset(email);
        flash.addFlashAttribute("success",
                "Si el correo existe, recibirás instrucciones en breve.");
        return "redirect:/auth/forgot-password";
    }

    @GetMapping("/reset-password")
    public String resetPage(@RequestParam String token, Model model) {
        model.addAttribute("token", token);
        return "auth/reset-password";
    }

    @PostMapping("/reset-password")
    public String resetSubmit(@RequestParam String token,
                              @RequestParam String newPassword,
                              @RequestParam String confirmPassword,
                              RedirectAttributes flash,
                              Model model) {
        try {
            userService.resetPassword(token, newPassword, confirmPassword);
            flash.addFlashAttribute("success", "Contraseña actualizada. Ya puedes iniciar sesión.");
            return "redirect:/auth/login";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            model.addAttribute("token", token);
            return "auth/reset-password";
        }
    }
}
