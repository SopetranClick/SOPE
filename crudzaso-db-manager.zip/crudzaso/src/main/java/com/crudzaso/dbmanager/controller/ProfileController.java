package com.crudzaso.dbmanager.controller;

import com.crudzaso.dbmanager.dto.ChangePasswordDTO;
import com.crudzaso.dbmanager.dto.ProfileUpdateDTO;
import com.crudzaso.dbmanager.entity.User;
import com.crudzaso.dbmanager.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/profile")
@RequiredArgsConstructor
public class ProfileController {

    private final UserService userService;

    @GetMapping
    public String profile(@AuthenticationPrincipal UserDetails principal, Model model) {
        User user = userService.findByEmail(principal.getUsername());
        ProfileUpdateDTO dto = new ProfileUpdateDTO();
        dto.setFirstName(user.getFirstName());
        dto.setLastName(user.getLastName());
        model.addAttribute("user", user);
        model.addAttribute("dto", dto);
        return "profile/index";
    }

    @PostMapping
    public String updateProfile(@Valid @ModelAttribute("dto") ProfileUpdateDTO dto,
                                BindingResult result,
                                @AuthenticationPrincipal UserDetails principal,
                                RedirectAttributes flash,
                                Model model) {
        User user = userService.findByEmail(principal.getUsername());
        if (result.hasErrors()) {
            model.addAttribute("user", user);
            return "profile/index";
        }
        userService.updateProfile(user.getId(), dto);
        flash.addFlashAttribute("success", "Perfil actualizado correctamente");
        return "redirect:/profile";
    }

    @GetMapping("/change-password")
    public String changePasswordPage(Model model) {
        model.addAttribute("dto", new ChangePasswordDTO());
        return "profile/change-password";
    }

    @PostMapping("/change-password")
    public String changePassword(@Valid @ModelAttribute("dto") ChangePasswordDTO dto,
                                 BindingResult result,
                                 @AuthenticationPrincipal UserDetails principal,
                                 RedirectAttributes flash,
                                 Model model) {
        if (result.hasErrors()) return "profile/change-password";
        try {
            User user = userService.findByEmail(principal.getUsername());
            userService.changePassword(user.getId(), dto);
            flash.addFlashAttribute("success", "Contraseña cambiada exitosamente");
            return "redirect:/profile";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            return "profile/change-password";
        }
    }
}
