package com.crudzaso.dbmanager.entity.enums;
public enum UserStatus { ACTIVE, BLOCKED }
