package com.crudzaso.dbmanager.entity.enums;
public enum DbStatus { CREATED, RUNNING, STOPPED, ARCHIVED }
