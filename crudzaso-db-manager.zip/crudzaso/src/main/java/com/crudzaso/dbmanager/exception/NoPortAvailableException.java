package com.crudzaso.dbmanager.exception;
public class NoPortAvailableException extends RuntimeException {
    public NoPortAvailableException(String msg) { super(msg); }
}
