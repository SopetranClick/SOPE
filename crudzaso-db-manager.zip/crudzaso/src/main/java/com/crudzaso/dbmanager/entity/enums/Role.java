package com.crudzaso.dbmanager.entity.enums;

public enum Role { USER, ADMIN }
