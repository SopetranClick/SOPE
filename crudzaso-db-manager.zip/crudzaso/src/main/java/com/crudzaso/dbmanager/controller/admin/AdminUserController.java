package com.crudzaso.dbmanager.controller.admin;

import com.crudzaso.dbmanager.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/admin/users")
@RequiredArgsConstructor
public class AdminUserController {

    private final UserService userService;

    @GetMapping
    public String list(@RequestParam(defaultValue = "") String search,
                       @RequestParam(defaultValue = "0") int page,
                       Model model) {
        Pageable pageable = PageRequest.of(page, 15, Sort.by("createdAt").descending());
        model.addAttribute("users", userService.searchUsers(search, pageable));
        model.addAttribute("search", search);
        return "admin/users/list";
    }

    @GetMapping("/{id}")
    public String detail(@PathVariable Long id, Model model) {
        model.addAttribute("user", userService.findById(id));
        return "admin/users/detail";
    }

    @PostMapping("/{id}/block")
    public String block(@PathVariable Long id, RedirectAttributes flash) {
        try {
            userService.blockUser(id);
            flash.addFlashAttribute("success", "Usuario bloqueado");
        } catch (IllegalArgumentException e) {
            flash.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/admin/users";
    }

    @PostMapping("/{id}/unblock")
    public String unblock(@PathVariable Long id, RedirectAttributes flash) {
        userService.unblockUser(id);
        flash.addFlashAttribute("success", "Usuario desbloqueado");
        return "redirect:/admin/users";
    }
}
