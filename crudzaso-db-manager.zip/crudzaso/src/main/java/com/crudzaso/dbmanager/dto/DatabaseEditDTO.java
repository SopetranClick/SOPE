package com.crudzaso.dbmanager.dto;

import com.crudzaso.dbmanager.entity.enums.DbStatus;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class DatabaseEditDTO {

    @NotBlank(message = "La descripción es obligatoria")
    @Size(max = 500)
    private String description;

    @NotNull
    private DbStatus status;
}
