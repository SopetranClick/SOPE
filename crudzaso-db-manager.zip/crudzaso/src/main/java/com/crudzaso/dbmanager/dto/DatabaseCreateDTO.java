package com.crudzaso.dbmanager.dto;

import com.crudzaso.dbmanager.entity.enums.DbEngine;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class DatabaseCreateDTO {

    @NotBlank(message = "El nombre es obligatorio")
    @Size(min = 3, max = 100, message = "El nombre debe tener entre 3 y 100 caracteres")
    @Pattern(regexp = "^[a-z][a-z0-9_]*$",
             message = "Solo letras minúsculas, números y guion bajo. Debe empezar con letra")
    private String name;

    @Size(max = 500)
    private String description;

    @NotNull(message = "Selecciona un motor de base de datos")
    private DbEngine engine;
}
