package com.crudzaso.dbmanager.service;

import com.crudzaso.dbmanager.entity.Database;
import com.crudzaso.dbmanager.entity.User;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class MailService {

    private final JavaMailSender mailSender;

    @Value("${app.base-url}")
    private String baseUrl;

    @Value("${spring.mail.username:noreply@crudzaso.com}")
    private String from;

    @Async
    public void sendWelcome(User user) {
        send(user.getEmail(),
             "¡Bienvenido a CrudZaso DB Manager!",
             "Hola " + user.getFirstName() + ",\n\n" +
             "Tu cuenta ha sido creada exitosamente.\n" +
             "Accede a la plataforma en: " + baseUrl + "/auth/login\n\n" +
             "CrudZaso DB Manager");
    }

    @Async
    public void sendPasswordReset(User user) {
        String link = baseUrl + "/auth/reset-password?token=" + user.getPasswordResetToken();
        send(user.getEmail(),
             "Recuperación de contraseña",
             "Hola " + user.getFirstName() + ",\n\n" +
             "Recibimos una solicitud para restablecer tu contraseña.\n" +
             "Haz clic en el siguiente enlace (válido por 1 hora):\n" + link +
             "\n\nSi no solicitaste este cambio, ignora este correo.\n\nCrudZaso DB Manager");
    }

    @Async
    public void sendPasswordChanged(User user) {
        send(user.getEmail(),
             "Tu contraseña ha sido cambiada",
             "Hola " + user.getFirstName() + ",\n\n" +
             "Tu contraseña fue actualizada exitosamente.\n" +
             "Si no realizaste este cambio, contacta al soporte inmediatamente.\n\nCrudZaso DB Manager");
    }

    @Async
    public void sendDatabaseCreated(User user, Database db) {
        send(user.getEmail(),
             "Base de datos creada: " + db.getName(),
             "Hola " + user.getFirstName() + ",\n\n" +
             "Tu base de datos ha sido creada exitosamente.\n\n" +
             "  Nombre:  " + db.getName() + "\n" +
             "  Motor:   " + db.getEngine() + "\n" +
             "  Puerto:  " + db.getPort() + "\n" +
             "  Usuario: " + db.getConnectionUser() + "\n\n" +
             "Consulta los detalles en: " + baseUrl + "/databases/" + db.getId() + "\n\n" +
             "CrudZaso DB Manager");
    }

    @Async
    public void sendDatabaseArchived(User user, Database db) {
        send(user.getEmail(),
             "Base de datos archivada: " + db.getName(),
             "Hola " + user.getFirstName() + ",\n\n" +
             "La base de datos '" + db.getName() + "' ha sido archivada y ya no podrá reactivarse.\n\n" +
             "CrudZaso DB Manager");
    }

    @Async
    public void sendUserBlocked(User user) {
        send(user.getEmail(),
             "Tu cuenta ha sido bloqueada",
             "Hola " + user.getFirstName() + ",\n\n" +
             "Tu cuenta en CrudZaso DB Manager ha sido bloqueada por un administrador.\n" +
             "Contacta al soporte si crees que es un error.\n\nCrudZaso DB Manager");
    }

    @Async
    public void sendUserUnblocked(User user) {
        send(user.getEmail(),
             "Tu cuenta ha sido desbloqueada",
             "Hola " + user.getFirstName() + ",\n\n" +
             "Tu cuenta en CrudZaso DB Manager ha sido desbloqueada. Ya puedes iniciar sesión.\n\n" +
             "CrudZaso DB Manager");
    }

    private void send(String to, String subject, String body) {
        try {
            SimpleMailMessage msg = new SimpleMailMessage();
            msg.setFrom(from);
            msg.setTo(to);
            msg.setSubject(subject);
            msg.setText(body);
            mailSender.send(msg);
            log.info("Correo enviado a {} - {}", to, subject);
        } catch (Exception e) {
            log.error("Error enviando correo a {}: {}", to, e.getMessage());
        }
    }
}
