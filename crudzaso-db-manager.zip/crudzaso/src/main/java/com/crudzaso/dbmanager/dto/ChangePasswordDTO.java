package com.crudzaso.dbmanager.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class ChangePasswordDTO {
    @NotBlank private String currentPassword;

    @NotBlank
    @Size(min = 8)
    @Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&_#])[A-Za-z\\d@$!%*?&_#]{8,}$",
             message = "La contraseña debe contener mayúscula, minúscula, número y carácter especial")
    private String newPassword;

    @NotBlank private String confirmPassword;
}
