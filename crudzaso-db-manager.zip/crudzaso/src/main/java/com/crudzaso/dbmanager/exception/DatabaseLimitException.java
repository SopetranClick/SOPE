package com.crudzaso.dbmanager.exception;

public class DatabaseLimitException extends RuntimeException {
    public DatabaseLimitException(String msg) { super(msg); }
}
