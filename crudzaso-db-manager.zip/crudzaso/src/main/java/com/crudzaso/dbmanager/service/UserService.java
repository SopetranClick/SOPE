package com.crudzaso.dbmanager.service;

import com.crudzaso.dbmanager.dto.ChangePasswordDTO;
import com.crudzaso.dbmanager.dto.ProfileUpdateDTO;
import com.crudzaso.dbmanager.dto.UserRegistrationDTO;
import com.crudzaso.dbmanager.entity.User;
import com.crudzaso.dbmanager.entity.enums.Role;
import com.crudzaso.dbmanager.entity.enums.UserStatus;
import com.crudzaso.dbmanager.exception.ResourceNotFoundException;
import com.crudzaso.dbmanager.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Transactional
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final MailService mailService;

    public User register(UserRegistrationDTO dto) {
        if (userRepository.existsByEmail(dto.getEmail()))
            throw new IllegalArgumentException("Ya existe una cuenta con ese correo electrónico");
        if (!dto.getPassword().equals(dto.getConfirmPassword()))
            throw new IllegalArgumentException("Las contraseñas no coinciden");

        User user = User.builder()
                .firstName(dto.getFirstName())
                .lastName(dto.getLastName())
                .email(dto.getEmail().toLowerCase().trim())
                .password(passwordEncoder.encode(dto.getPassword()))
                .role(Role.USER)
                .status(UserStatus.ACTIVE)
                .build();

        userRepository.save(user);
        mailService.sendWelcome(user);
        return user;
    }

    @Transactional(readOnly = true)
    public User findById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado"));
    }

    @Transactional(readOnly = true)
    public User findByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado"));
    }

    @Transactional(readOnly = true)
    public Page<User> searchUsers(String query, Pageable pageable) {
        if (query == null || query.isBlank())
            return userRepository.findAll(pageable);
        return userRepository
                .findByFirstNameContainingIgnoreCaseOrLastNameContainingIgnoreCaseOrEmailContainingIgnoreCase(
                        query, query, query, pageable);
    }

    public void updateProfile(Long userId, ProfileUpdateDTO dto) {
        User user = findById(userId);
        user.setFirstName(dto.getFirstName());
        user.setLastName(dto.getLastName());
        userRepository.save(user);
    }

    public void changePassword(Long userId, ChangePasswordDTO dto) {
        User user = findById(userId);
        if (!passwordEncoder.matches(dto.getCurrentPassword(), user.getPassword()))
            throw new IllegalArgumentException("La contraseña actual es incorrecta");
        if (!dto.getNewPassword().equals(dto.getConfirmPassword()))
            throw new IllegalArgumentException("Las contraseñas nuevas no coinciden");

        user.setPassword(passwordEncoder.encode(dto.getNewPassword()));
        userRepository.save(user);
        mailService.sendPasswordChanged(user);
    }

    public void initiatePasswordReset(String email) {
        userRepository.findByEmail(email).ifPresent(user -> {
            user.setPasswordResetToken(UUID.randomUUID().toString());
            user.setPasswordResetExpiry(LocalDateTime.now().plusHours(1));
            userRepository.save(user);
            mailService.sendPasswordReset(user);
        });
    }

    public void resetPassword(String token, String newPassword, String confirmPassword) {
        if (!newPassword.equals(confirmPassword))
            throw new IllegalArgumentException("Las contraseñas no coinciden");

        User user = userRepository.findByPasswordResetToken(token)
                .orElseThrow(() -> new IllegalArgumentException("Token inválido o expirado"));

        if (user.getPasswordResetExpiry().isBefore(LocalDateTime.now()))
            throw new IllegalArgumentException("El enlace de recuperación ha expirado");

        user.setPassword(passwordEncoder.encode(newPassword));
        user.setPasswordResetToken(null);
        user.setPasswordResetExpiry(null);
        userRepository.save(user);
        mailService.sendPasswordChanged(user);
    }

    public void blockUser(Long id) {
        User user = findById(id);
        if (user.isAdmin()) throw new IllegalArgumentException("No se puede bloquear a un administrador");
        user.setStatus(UserStatus.BLOCKED);
        userRepository.save(user);
        mailService.sendUserBlocked(user);
    }

    public void unblockUser(Long id) {
        User user = findById(id);
        user.setStatus(UserStatus.ACTIVE);
        userRepository.save(user);
        mailService.sendUserUnblocked(user);
    }

    @Transactional(readOnly = true)
    public long countTotal()   { return userRepository.count(); }
    @Transactional(readOnly = true)
    public long countActive()  { return userRepository.countActive(); }
    @Transactional(readOnly = true)
    public long countBlocked() { return userRepository.countBlocked(); }
}
