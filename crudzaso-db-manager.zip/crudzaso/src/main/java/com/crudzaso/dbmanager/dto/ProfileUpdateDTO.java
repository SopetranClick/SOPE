package com.crudzaso.dbmanager.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class ProfileUpdateDTO {
    @NotBlank @Size(max = 100) private String firstName;
    @NotBlank @Size(max = 100) private String lastName;
}
