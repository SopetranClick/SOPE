package com.crudzaso.dbmanager.service;

import com.crudzaso.dbmanager.repository.DatabaseRepository;
import com.crudzaso.dbmanager.util.PasswordGenerator;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class CredentialGeneratorService {

    private final DatabaseRepository databaseRepository;

    public String generateUniqueUser() {
        String candidate;
        int attempts = 0;
        do {
            candidate = "usr_" + UUID.randomUUID().toString().replace("-", "").substring(0, 12);
            if (++attempts > 100) throw new IllegalStateException("No se pudo generar un usuario único");
        } while (databaseRepository.existsByConnectionUser(candidate));
        return candidate;
    }

    public String generateSecurePassword() {
        String candidate;
        int attempts = 0;
        do {
            candidate = PasswordGenerator.generate(24);
            if (++attempts > 100) throw new IllegalStateException("No se pudo generar una contraseña única");
        } while (databaseRepository.existsByConnectionPassword(candidate));
        return candidate;
    }
}
