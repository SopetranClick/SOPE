package com.crudzaso.dbmanager.repository;

import com.crudzaso.dbmanager.entity.Database;
import com.crudzaso.dbmanager.entity.User;
import com.crudzaso.dbmanager.entity.enums.DbEngine;
import com.crudzaso.dbmanager.entity.enums.DbStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Set;

public interface DatabaseRepository extends JpaRepository<Database, Long> {

    List<Database> findByOwnerOrderByCreatedAtDesc(User owner);

    boolean existsByNameAndOwner(String name, User owner);
    boolean existsByConnectionUser(String connectionUser);
    boolean existsByConnectionPassword(String connectionPassword);

    @Query("SELECT COUNT(d) FROM Database d WHERE d.owner.id = :userId AND d.status <> 'ARCHIVED'")
    long countActiveByOwner(@Param("userId") Long userId);

    @Query("SELECT d.port FROM Database d WHERE d.status <> 'ARCHIVED'")
    Set<Integer> findAllActivePorts();

    // Admin search
    @Query("""
        SELECT d FROM Database d JOIN d.owner o
        WHERE (:search IS NULL OR :search = ''
               OR LOWER(d.name) LIKE LOWER(CONCAT('%', :search, '%'))
               OR LOWER(o.email) LIKE LOWER(CONCAT('%', :search, '%'))
               OR LOWER(o.firstName) LIKE LOWER(CONCAT('%', :search, '%')))
           AND (:engine IS NULL OR d.engine = :engine)
        """)
    Page<Database> searchAdmin(@Param("search") String search,
                               @Param("engine") DbEngine engine,
                               Pageable pageable);

    // Stats
    @Query("SELECT d.engine, COUNT(d) FROM Database d GROUP BY d.engine")
    List<Object[]> countByEngine();

    @Query("SELECT d.status, COUNT(d) FROM Database d GROUP BY d.status")
    List<Object[]> countByStatus();

    @Query("SELECT o.email, COUNT(d) FROM Database d JOIN d.owner o GROUP BY o.email ORDER BY COUNT(d) DESC")
    List<Object[]> countByOwner();

    long countByStatus(DbStatus status);
}
