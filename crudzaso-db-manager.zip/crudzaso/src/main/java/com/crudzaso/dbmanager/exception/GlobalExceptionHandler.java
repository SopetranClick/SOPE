package com.crudzaso.dbmanager.exception;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ResourceNotFoundException.class)
    public String handleNotFound(ResourceNotFoundException ex, Model model) {
        model.addAttribute("error", ex.getMessage());
        return "error/404";
    }

    @ExceptionHandler(AccessDeniedException.class)
    public String handleAccess(AccessDeniedException ex, Model model) {
        model.addAttribute("error", ex.getMessage());
        return "error/403";
    }

    @ExceptionHandler({DatabaseLimitException.class, DuplicateNameException.class, NoPortAvailableException.class})
    public String handleBusiness(RuntimeException ex, Model model) {
        model.addAttribute("error", ex.getMessage());
        return "error/business";
    }
}
