package com.crudzaso.dbmanager.controller.admin;

import com.crudzaso.dbmanager.entity.enums.DbEngine;
import com.crudzaso.dbmanager.entity.enums.DbStatus;
import com.crudzaso.dbmanager.service.DatabaseService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/admin/databases")
@RequiredArgsConstructor
public class AdminDatabaseController {

    private final DatabaseService databaseService;

    @GetMapping
    public String list(@RequestParam(defaultValue = "") String search,
                       @RequestParam(required = false) DbEngine engine,
                       @RequestParam(defaultValue = "0") int page,
                       Model model) {
        Pageable pageable = PageRequest.of(page, 15, Sort.by("createdAt").descending());
        model.addAttribute("databases", databaseService.searchAdmin(search, engine, pageable));
        model.addAttribute("search", search);
        model.addAttribute("selectedEngine", engine);
        model.addAttribute("engines", DbEngine.values());
        return "admin/databases/list";
    }

    @GetMapping("/{id}")
    public String detail(@PathVariable Long id, Model model) {
        model.addAttribute("db", databaseService.findById(id));
        model.addAttribute("statuses", DbStatus.values());
        return "admin/databases/detail";
    }

    @PostMapping("/{id}/status")
    public String changeStatus(@PathVariable Long id,
                               @RequestParam DbStatus status,
                               RedirectAttributes flash) {
        try {
            databaseService.changeStatus(id, status);
            flash.addFlashAttribute("success", "Estado actualizado a " + status);
        } catch (RuntimeException e) {
            flash.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/admin/databases/" + id;
    }
}
