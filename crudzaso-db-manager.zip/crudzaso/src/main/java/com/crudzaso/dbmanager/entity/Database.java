package com.crudzaso.dbmanager.entity;

import com.crudzaso.dbmanager.entity.enums.DbEngine;
import com.crudzaso.dbmanager.entity.enums.DbStatus;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "databases",
       uniqueConstraints = @UniqueConstraint(columnNames = {"name", "user_id"}))
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Database {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String name;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, updatable = false)
    private DbEngine engine;

    @Column(name = "connection_user", nullable = false, unique = true, updatable = false, length = 50)
    private String connectionUser;

    @Column(name = "connection_password", nullable = false, unique = true, length = 255)
    private String connectionPassword;

    @Column(nullable = false, updatable = false)
    private Integer port;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private DbStatus status;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User owner;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    @PrePersist
    void onCreate() {
        createdAt = updatedAt = LocalDateTime.now();
        if (status == null) status = DbStatus.CREATED;
    }

    @PreUpdate
    void onUpdate() { updatedAt = LocalDateTime.now(); }

    public boolean isArchived()  { return status == DbStatus.ARCHIVED; }
    public boolean isActive()    { return status != DbStatus.ARCHIVED; }
}
