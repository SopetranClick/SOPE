package com.crudzaso.dbmanager.service;

import com.crudzaso.dbmanager.exception.NoPortAvailableException;
import com.crudzaso.dbmanager.repository.DatabaseRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
@RequiredArgsConstructor
public class PortAssignmentService {

    private final DatabaseRepository databaseRepository;

    @Value("${app.db.port-range-start:15000}")
    private int portStart;

    @Value("${app.db.port-range-end:15999}")
    private int portEnd;

    public int assignAvailablePort() {
        Set<Integer> used = databaseRepository.findAllActivePorts();
        for (int port = portStart; port <= portEnd; port++) {
            if (!used.contains(port)) return port;
        }
        throw new NoPortAvailableException("No hay puertos disponibles en el rango configurado");
    }
}
