package com.crudzaso.dbmanager.controller.admin;

import com.crudzaso.dbmanager.service.DatabaseService;
import com.crudzaso.dbmanager.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin")
@RequiredArgsConstructor
public class AdminDashboardController {

    private final UserService userService;
    private final DatabaseService databaseService;

    @GetMapping({"/dashboard", ""})
    public String dashboard(Model model) {
        model.addAttribute("totalUsers",    userService.countTotal());
        model.addAttribute("activeUsers",   userService.countActive());
        model.addAttribute("blockedUsers",  userService.countBlocked());
        model.addAttribute("totalDbs",      databaseService.countTotal());
        model.addAttribute("dbsByEngine",   databaseService.statsByEngine());
        model.addAttribute("dbsByStatus",   databaseService.statsByStatus());
        model.addAttribute("dbsByOwner",    databaseService.statsByOwner());
        return "admin/dashboard";
    }

    @GetMapping("/stats")
    public String stats(Model model) {
        var byEngine = databaseService.statsByEngine();
        var byStatus = databaseService.statsByStatus();
        var byOwner  = databaseService.statsByOwner();

        model.addAttribute("dbsByEngine",  byEngine);
        model.addAttribute("dbsByStatus",  byStatus);
        model.addAttribute("dbsByOwner",   byOwner);
        model.addAttribute("totalUsers",   userService.countTotal());
        model.addAttribute("activeUsers",  userService.countActive());
        model.addAttribute("blockedUsers", userService.countBlocked());
        model.addAttribute("totalDbs",     databaseService.countTotal());

        // For Chart.js — serialized as JSON arrays
        model.addAttribute("engineLabels", byEngine.keySet());
        model.addAttribute("engineValues", byEngine.values());
        model.addAttribute("statusLabels", byStatus.keySet());
        model.addAttribute("statusValues", byStatus.values());
        return "admin/stats";
    }
}
