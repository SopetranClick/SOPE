package com.crudzaso.dbmanager.controller;

import com.crudzaso.dbmanager.entity.User;
import com.crudzaso.dbmanager.entity.enums.DbStatus;
import com.crudzaso.dbmanager.service.DatabaseService;
import com.crudzaso.dbmanager.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
@RequiredArgsConstructor
public class DashboardController {

    private final UserService userService;
    private final DatabaseService databaseService;

    @GetMapping("/")
    public String home() { return "index"; }

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal UserDetails principal, Model model) {
        User user = userService.findByEmail(principal.getUsername());
        var dbs = databaseService.findByOwner(user.getId());

        model.addAttribute("user", user);
        model.addAttribute("databases", dbs);
        model.addAttribute("totalDbs", dbs.size());
        model.addAttribute("runningDbs", dbs.stream().filter(d -> d.getStatus() == DbStatus.RUNNING).count());
        model.addAttribute("stoppedDbs", dbs.stream().filter(d -> d.getStatus() == DbStatus.STOPPED).count());
        model.addAttribute("activeSlots", 3 - dbs.stream().filter(d -> !d.isArchived()).count());
        return "dashboard";
    }
}
