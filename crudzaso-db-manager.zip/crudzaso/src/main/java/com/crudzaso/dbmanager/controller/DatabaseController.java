package com.crudzaso.dbmanager.controller;

import com.crudzaso.dbmanager.dto.DatabaseCreateDTO;
import com.crudzaso.dbmanager.dto.DatabaseEditDTO;
import com.crudzaso.dbmanager.entity.Database;
import com.crudzaso.dbmanager.entity.User;
import com.crudzaso.dbmanager.entity.enums.DbEngine;
import com.crudzaso.dbmanager.entity.enums.DbStatus;
import com.crudzaso.dbmanager.service.DatabaseService;
import com.crudzaso.dbmanager.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/databases")
@RequiredArgsConstructor
public class DatabaseController {

    private final DatabaseService databaseService;
    private final UserService userService;

    private User currentUser(UserDetails p) { return userService.findByEmail(p.getUsername()); }

    @GetMapping
    public String list(@AuthenticationPrincipal UserDetails principal, Model model) {
        User user = currentUser(principal);
        model.addAttribute("databases", databaseService.findByOwner(user.getId()));
        model.addAttribute("user", user);
        return "databases/list";
    }

    @GetMapping("/new")
    public String createForm(Model model) {
        model.addAttribute("dto", new DatabaseCreateDTO());
        model.addAttribute("engines", DbEngine.values());
        return "databases/create";
    }

    @PostMapping("/new")
    public String create(@Valid @ModelAttribute("dto") DatabaseCreateDTO dto,
                         BindingResult result,
                         @AuthenticationPrincipal UserDetails principal,
                         RedirectAttributes flash,
                         Model model) {
        if (result.hasErrors()) {
            model.addAttribute("engines", DbEngine.values());
            return "databases/create";
        }
        try {
            User user = currentUser(principal);
            Database db = databaseService.create(dto, user.getId());
            flash.addFlashAttribute("success", "Base de datos '" + db.getName() + "' creada exitosamente");
            return "redirect:/databases/" + db.getId();
        } catch (RuntimeException e) {
            model.addAttribute("error", e.getMessage());
            model.addAttribute("engines", DbEngine.values());
            return "databases/create";
        }
    }

    @GetMapping("/{id}")
    public String detail(@PathVariable Long id,
                         @AuthenticationPrincipal UserDetails principal,
                         Model model) {
        User user = currentUser(principal);
        Database db = databaseService.findByIdForUser(id, user.getId(), user.isAdmin());
        model.addAttribute("db", db);
        model.addAttribute("user", user);
        return "databases/detail";
    }

    @GetMapping("/{id}/edit")
    public String editForm(@PathVariable Long id,
                           @AuthenticationPrincipal UserDetails principal,
                           Model model) {
        User user = currentUser(principal);
        Database db = databaseService.findByIdForUser(id, user.getId(), user.isAdmin());

        DatabaseEditDTO dto = new DatabaseEditDTO();
        dto.setDescription(db.getDescription());
        dto.setStatus(db.getStatus());

        model.addAttribute("db", db);
        model.addAttribute("dto", dto);
        model.addAttribute("statuses", new DbStatus[]{DbStatus.CREATED, DbStatus.RUNNING, DbStatus.STOPPED});
        return "databases/edit";
    }

    @PostMapping("/{id}/edit")
    public String edit(@PathVariable Long id,
                       @Valid @ModelAttribute("dto") DatabaseEditDTO dto,
                       BindingResult result,
                       @AuthenticationPrincipal UserDetails principal,
                       RedirectAttributes flash,
                       Model model) {
        User user = currentUser(principal);
        if (result.hasErrors()) {
            model.addAttribute("db", databaseService.findById(id));
            model.addAttribute("statuses", new DbStatus[]{DbStatus.CREATED, DbStatus.RUNNING, DbStatus.STOPPED});
            return "databases/edit";
        }
        try {
            databaseService.update(id, dto, user.getId(), user.isAdmin());
            flash.addFlashAttribute("success", "Base de datos actualizada");
            return "redirect:/databases/" + id;
        } catch (RuntimeException e) {
            model.addAttribute("error", e.getMessage());
            model.addAttribute("db", databaseService.findById(id));
            model.addAttribute("statuses", new DbStatus[]{DbStatus.CREATED, DbStatus.RUNNING, DbStatus.STOPPED});
            return "databases/edit";
        }
    }

    @PostMapping("/{id}/archive")
    public String archive(@PathVariable Long id,
                          @AuthenticationPrincipal UserDetails principal,
                          RedirectAttributes flash) {
        User user = currentUser(principal);
        databaseService.archive(id, user.getId(), user.isAdmin());
        flash.addFlashAttribute("success", "Base de datos archivada");
        return "redirect:/databases";
    }
}
